import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import static java.awt.event.KeyEvent.*;

public class Panel extends JPanel {

    Room buttons[];
    ArrayList<Question> questions;
    int currentPos;
    int endPosition;
    Panel(){
        currentPos=0;
        endPosition=15;
        questions=new ArrayList<>();
        setLayout(new GridLayout(4,1));
        buttons=new Room[16];

        Random r=new Random();
        int index=0;
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++) {

                buttons[index] = new Room(r.nextBoolean(), r.nextBoolean(), r.nextBoolean(), r.nextBoolean());
                if(i==0){
                    buttons[index].north=false;
                }
                else if(i==3){
                    buttons[index].south=false;
                }
                if(j==0){
                    buttons[index].west=false;
                }
                else if(j==3){
                    buttons[index].east=false;
                }
                add(buttons[index]);
                index++;
            }

        }
        generatePath();
        buttons[currentPos].setText("P");
        buttons[endPosition].setText("E");

        setOpaque(false);
        connectToDB();
    }

    public void generatePath(){
        try {
            File myObj = new File("paths.txt");
            Scanner myReader = new Scanner(myObj);
            ArrayList<String> data=new ArrayList<>();
            while (myReader.hasNextLine()) {
                data.add(myReader.nextLine());
            }
            Random rand=new Random();
            String path=data.get(rand.nextInt(data.size()));
            String[]pathStr=path.split(" ");
            int[]pathNodes=new int[pathStr.length];
            for(int i=0;i<pathStr.length;i++){
                pathNodes[i]= Integer.parseInt(pathStr[i]);
            }

            int prev=0;
            for(int i=1;i<pathNodes.length;i++){
                if(pathNodes[i]-pathNodes[prev]==1){
                    buttons[pathNodes[prev]].east=true;
                }
                else if(pathNodes[i]-pathNodes[prev]==-1){
                    buttons[pathNodes[prev]].west=true;
                }
                else if(pathNodes[i]-pathNodes[prev]==4){
                    buttons[pathNodes[prev]].south=true;
                }
                prev=i;
            }
            myReader.close();
        } catch (FileNotFoundException ex) {
            System.out.println("An error occurred.");
            ex.printStackTrace();
        }
    }

    public void connectToDB(){
        Connection conn = null;
        try {
            // db parameters
       //     String url = "jdbc:sqlite:D:/Documents/Idea Projects/Dungeon/ques.db";
            String url = "jdbc:sqlite:ques.db";
            // create a connection to the database
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection(url);

            System.out.println("Connection to SQLite has been established.");

            String query="Select*from Question";
            PreparedStatement pst=conn.prepareStatement(query);
            ResultSet rs=pst.executeQuery();
            while(rs.next()){
                String ques=rs.getString("Statement");
                String ans=rs.getString("Answer");
                int type=rs.getInt("Type");
                Question q=new Question(ques,ans,type);
                questions.add(q);
            }
            rs.close();
            pst.close();
            conn.close();
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    public void actionListener(KeyEvent e){
        Random rand=new Random();
        if(e.getKeyCode()==VK_UP && buttons[currentPos].north){

                int r=rand.nextInt(13);
                String answer=JOptionPane.showInputDialog(questions.get(r).question);
                if(answer.equalsIgnoreCase(questions.get(r).answer)) {
                    buttons[currentPos].setText("");
                    currentPos -= 4;
                    buttons[currentPos].setText("P");
                }
                else{
                    JOptionPane.showMessageDialog(new JFrame(),"Incorrect answer!");
                    buttons[currentPos].north=false;
                }

        }
        else if(e.getKeyCode()==VK_DOWN && buttons[currentPos].south){
            int r=rand.nextInt(13);
            String answer=JOptionPane.showInputDialog(questions.get(r).question);
            if(answer.equalsIgnoreCase(questions.get(r).answer)) {
                buttons[currentPos].setText("");
                currentPos += 4;
                buttons[currentPos].setText("P");
            }
            else{
                JOptionPane.showMessageDialog(new JFrame(),"Incorrect answer!");
                buttons[currentPos].south=false;
            }
        }
        else if(e.getKeyCode()==VK_LEFT && buttons[currentPos].west){
            int r=rand.nextInt(13);
            String answer=JOptionPane.showInputDialog(questions.get(r).question);
            if(answer.equalsIgnoreCase(questions.get(r).answer)) {
                buttons[currentPos].setText("");
                currentPos -= 1;
                buttons[currentPos].setText("P");
            }
            else{
                JOptionPane.showMessageDialog(new JFrame(),"Incorrect answer!");
                buttons[currentPos].west=false;
            }
        }
        else if(e.getKeyCode()==VK_RIGHT && buttons[currentPos].east){
            int r=rand.nextInt(13);
            String answer=JOptionPane.showInputDialog(questions.get(r).question);
            if(answer.equalsIgnoreCase(questions.get(r).answer)) {
                buttons[currentPos].setText("");
                currentPos += 1;
                buttons[currentPos].setText("P");
            }
            else{
                JOptionPane.showMessageDialog(new JFrame(),"Incorrect answer!");
                buttons[currentPos].east=false;
            }
        }
        if(currentPos==endPosition){
            JOptionPane.showMessageDialog(new JFrame(),"You Won!");
        }
        if(!buttons[currentPos].north && !buttons[currentPos].south && !buttons[currentPos].east && !buttons[currentPos].west){
            JOptionPane.showMessageDialog(new JFrame(),"You Lost!");
            System.exit(1);
        }
    }
}
